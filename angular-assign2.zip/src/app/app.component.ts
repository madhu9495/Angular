import { Component } from '@angular/core';

@Component({
  selector: 'my-app',
  templateUrl: './app.component.html',
  styleUrls: [ './app.component.css' ]
})
export class AppComponent  {
  username: string;
  city: string;
  today: number = Date.now();
  toUpperCaseUser (newvalue) {
    this.username = newvalue.toUpperCase();
  }
  toUpperCaseCity (newvalue) {
    this.city = newvalue.toUpperCase();
  }
   
}
