
var app = angular.module('myApp', []);
app.controller('CDController', function($scope) {
            $scope.CD = {
               CDId: "101",
               CDTitle: "Victory",
               CDPrice: "200$",
               
               getAllDetails: function() {
                  var CDObj;
                  CDObj = $scope.CD;
                  return "CDId :"+CDObj.CDId + " CDTitle :" + CDObj.CDTitle+" CDPrice : "+CDObj.CDPrice;
               }
            };
         });