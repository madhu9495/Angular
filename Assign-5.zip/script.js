
var app = angular.module('myApp', []);
app.controller('CDController', function($scope) {
           var CDShops = [
             {
               name: "Sony Music Store",
               address: "Hyderabad",
               Stock: [
                 {title : "Thriller", language:"English",price:"70$"},
                 {title : "Dangerous", language:"English",price:"62$"},
                 {title : "History", language:"French",price:"40$"},
                 {title : "Bad", language:"Italian",price:"30$"},
                 ]
             
             },
             {
               name: "VMV Store",
               address: "Vizag",
               Stock: [
                 {title : "Doom", language:"English",price:"70$"},
                 {title : "Hang", language:"English",price:"62$"},
                 {title : "Nature", language:"French",price:"40$"},
                 {title : "God", language:"Italian",price:"30$"},
                 ]
             
             }
             ];
             $scope.CDShops =CDShops;
          
         });